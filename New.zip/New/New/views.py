from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
from django.views.decorators.csrf import csrf_exempt
from .forms import SignupForm
# Create your views here.
def signupform(request):
 #if form is submitted
 if request.method == 'POST':
     fname=request.POST.get('fname')
     lname=request.POST.get('lname')
     email=request.POST.get('email')
     phone=request.POST.get('phone')
     country=request.POST.get('country')

     context={
         'fname':fname,
         'email':email,
         'lname':lname,
         'phone':phone,
         'country':country
     }
     template=loader.get_template('showdata.html')
     return HttpResponse(template.render(context,request))
 else:
     template=loader.get_template('signupform.html')
     return HttpResponse(template.render())